a(i) is the even fourier coefficient,which i get by integral the coskx
b(i) is the  odd fourier coefficent,which i can get by integral the sinkx
each time I change the number of coefficient,i plot the z as the sum of odd part and even part.
we can see at each function,the border will shake violently,and the function I give is 
val =(1911387046407553*sin(3*x))/4503599627370496 + (4587328911378127*sin(5*x))/18014398509481984 + (6553327016254467*sin(7*x))/36028797018963968 +
(5734161139222659*sin(x))/4503599627370496(when n=8)
