syms x;
y=1.*(x>=0)+(-1).*(x<0);
y=2*heaviside(x)-1;
T=pi;
a=[];
b=[];
a0=1/(2*T)*int(y,x,[-pi,pi]);
z=a0;.
Nmax=8;
Nmin=5;
xlim([-8,8]);
fplot(y);
hold on;
for j=Nmin:Nmax
    z=a0;
for i=1:j
    a(i)=1/T*int(y*cos(i*x),x,[-pi,pi]);
    b(i)=1/T*int(y*sin(i*x),x,[-pi,pi]);
    z=z+a(i)*cos(i*x)+b(i)*sin(i*x);
    
end
fplot(z);
hold on
end
%val =(1911387046407553*sin(3*x))/4503599627370496 + (4587328911378127*sin(5*x))/18014398509481984 + 
%(6553327016254467*sin(7*x))/36028797018963968 +
%(5734161139222659*sin(x))/4503599627370496(when n=8)
