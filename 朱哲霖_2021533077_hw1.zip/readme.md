## in the code,first I construct $K_5$ matrix
## then I get the eigenvalues
## compare it to 2*ones(5,1)-2*cos([1:5]*pi/6)' we will find it is same